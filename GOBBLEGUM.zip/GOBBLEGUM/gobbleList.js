// FUCK THIS SPAGHETTI CODE, IM GOING TO KILL MYSELF IF I HAVE
// TO TYPE OUT ONE MORE FUCKING GOBBLEGUM AND NUMBER OR IF I 
// HAVE TO COPY AND PASTE ONE MORE FUCKING FUNCTION BOILERPLATE

function randomG(min,max) {
    // HANDLING THE RETURN OF THE MATH.RANDOM NUMBERS
    z = Math.floor(Math.random() * (max - min) + min);

    // HERE COMES THE SPAGHETTI CODE, I PUT THIS
    // INTO A SEPERATE FILE SO I COULD MAKE THE
    // MAIN FILE LOOK NEATER WITHOUT ALL OF THIS
    // HORRENDOUS MESS. ALL THIS IS IS I AM GETTING
    // WHATEVER NUMBER WAS RETUTNED AND ASSIGNING 
    // A GOBBLEGUM TO IT AND OUTPUTTING WHICH
    // GOBBLEGUM YOU GOT.
    //
    // THIS ISNT PERFECT SINCE ITS MESSY AND 
    // YOU CAN PULL DUPLICATE GOBBLEGUMS BUT
    // IT WILL DO FOR NOW. IM GONNA GO KMS BRB

    // vv MEGAS vv

    if (z == 1) {
        z = 'AFTERTASTE'
    } if (z == 2) {
        z = 'BURNED OUT'
    } if (z == 3) {
        z = 'DEAD OF NUCLEAR WINTER'
    } if (z == 4) {
        z = 'EPHEMERAL ENHANCEMENT'
    } if (z == 5) {
        z = 'IMMOLATION LIQUIDATION'
    } if (z == 6) {
        z = 'LICENSED CONTRACTOR'
    } if (z == 7) {
        z = 'PHOENIX UP'
    } if (z == 8) {
        z = 'POP SHOCKS'
    } if (z == 9) {
        z = 'UNQUENCHABLE'
    } if (z == 10) {
        z = 'WHO\'S KEEPING SCORE?'
    } if (z == 11) {
        z = 'CRAWL SPACE'
    } if (z == 12) {
        z = 'FATAL CONTRAPTION'
    } if (z == 13) {
        z = 'DISORDERLY COMBAT'
    } if (z == 14) {
        z = 'SLAUGHTER SLIDE'
    } if (z == 15) {
        z = 'MIND BLOWN'
    } if (z == 16) {
        z = 'BOARD GAMES'
    } if (z == 17) {
        z = 'FLAVOR HEXED'
    } if (z == 18) {
        z = 'IDLE EYES'
    } if (z == 19) {
        z = 'CACHE BACK'
    } if (z == 20) {
        z = 'KILL JOY'
    } if (z == 21) {
        z = 'ON THE HOUSE'
    } if (z == 22) {
        z = 'WALL POWER'
    } if (z == 23) {
        z = 'FEAR IN HEADLIGHTS'
    } if (z == 24) {
        z = 'TEMPORAL GIFT'
    } if (z == 25) {
        z = 'CRATE POWER'
    } if (z == 26) {
        z = 'BULLET BOOST'
    } if (z == 27) {
        z = 'SODA FOUNTAIN'
    } if (z == 28) {
        z = 'KILLING TIME'
    } if (z == 29) {
        z = 'PERKAHOLIC'
    } if (z == 30) {
        z = 'HEAD DRAMA'
    } if (z == 31) {
        z = 'SECRET SHOPPER'
    } if (z == 32) {
        z = 'NEAR DEATH EXPERIENCE'
    } if (z == 33) {
        z = 'PROFIT SHARING'
    } if (z == 34) {
        z = 'ROUND ROBBIN\''
    } if (z == 35) {
        z = 'SELF MEDICATION'
    } if (z == 36) {
        z = 'REIGN DROPS'
    } if (z == 37) {
        z = 'I\'M FEELING LUCKY'
    } if (z == 38) {
        z = 'RESPIN CYCLE'
    } if (z == 39) {
        z = 'UNBEARABLE'
    } if (z == 40) {
        z = 'BOARD TO DEATH'
    } if (z == 41) {
        z = 'UNDEAD MAN WALKING'
    } if (z == 42) {
        z = 'EXTRA CREDIT'
    } if (z == 43) {
        z = 'SHOPPING FREE'
    } if (z == 44) {
        z = 'POWER VACUUM'
    } 
    
    // ^^ MEGAS ^^

    // vv CLASSICS vv

    if (z == 45) {
        z = 'ALWAYS DONE SWIFTLY - C'
    } if (z == 46) {
        z = 'ARMS GRACE - C'
    } if (z == 47) {
        z = 'COAGULANT - C'
    } if (z == 48) {
        z = 'IN PLAIN SIGHT - C'
    } if (z == 49) {
        z = 'STOCK OPTION - C'
    } if (z == 50) {
        z = 'IMPATIENT - C'
    } if (z == 51) {
        z = 'SWORD FLAY - C'
    } if (z == 52) {
        z = 'ANYWHERE BUT HERE - C'
    } if (z == 53) {
        z = 'DANGER CLOSEST - C'
    } if (z == 54) {
        z = 'ARMAMENTAL ACCOMPLISHMENT - C'
    } if (z == 55) {
        z = 'FIRING ON ALL CYLINDERS - C'
    } if (z == 56) {
        z = 'ARSENAL ACCELERATOR - C'
    } if (z == 57) {
        z = 'LUCKY CRIT - C'
    } if (z == 58) {
        z = 'NOW YOU SEE ME - C'
    } if (z == 59) {
        z = 'ALCHEMICAL ANTITHESIS - C'
    } 

    // ^^ CLASICS ^^

    // vv DLC CLASSICS vv

    if (z == 60) {
        z = 'PROJECTILE VOMITING - DLC'
    } if (z == 61) {
        z = 'NEWTONIAN NEGATION - DLC'
    } if (z == 62) {
        z = 'EYE CANDY - DLC'
    } if (z == 63) {
        z = 'TONE DEATH - DLC'
    } 

    // AIGHT IM BACK FROM KMS-ING,
    // AND IM READY TO EXPLAIN MORE
    // CODE. THIS IS JUST OUTPUTTING
    // WHATEVER NUMBER YOU PULLED
    // AND LOGGING IT AS THE GOBBLEGUM.

    return console.log(z);
}

// THIS IS JUST EXPORTING THE FUNCTION
// SO YOU ARE ABLE TO IMPORT IT IN THE
// MAIN.JS FILE SO WE CAN USE IT THERE
// INSTEAD OF SPAGHETTI CODING THE FILE

module.exports = { randomG };






// Side note:To make it so i can chose if
// i want only megas or megas and classic 
// gobblegums, i just made 1-44 is the me
// gas and everything after that is the c
// lassic gobblegums so i can just make i
// t so you pull just lower numbers for l
// ess option. its easier to explain in m
// y brain.