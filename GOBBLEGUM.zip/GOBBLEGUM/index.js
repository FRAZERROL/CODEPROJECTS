// IMPORT PROMT TO HAND CLI INTERACTIONS
const prompt = require('prompt-sync')({sigint: true});
// IMPORT RANDOMG FUNCTION FROM OTHER FILE TO HIDE SPAGHETTI CODE
const { randomG } = require('./gobbleList');

// PRINING OUT BOILERPLATE TEXT
console.log('\n-- RANDOM GOBBLEGUM GENERATOR --\n')
console.log('Would you like:\n\nOnly Megas - m\nMegas and classics - c\nMegas, classics and DLC classics - d\n')
// PROMPTING ANSWER TO TAKE IN EITHER m i OR d FOR THE APPROPIATE GOBBLES
const i = prompt('I would like: ');

// HANDLING CLI INPUT AND RETURNING APPROPIATE OPTIONED NUMBERS

if (i == 'm') {
    console.log('\n\n -- ONLY MEGAS -- \n')
    for (let i = 0; i < 5; i++) {
        randomG(1,44)
    }
    console.log('\n-- ONLY MEGAS -- \n')
} else if (i == 'c') {
    console.log('\n\n -- MEGAS AND CLASSICS -- \n')
    for (let i = 0; i < 5; i++) {
        randomG(1,59)
    }
    console.log('\n -- MEGAS AND CLASSICS -- \n')
} else if (i =='d') {
    console.log('\n\n -- MEGAS, CLASSICS AND DLC CLASSICS -- \n')
    for (let i = 0; i < 5; i++) {
        randomG(1,63)
    }
    console.log('\n -- MEGAS, CLASSICS AND DLC CLASSICS -- \n')
} else {
    console.log('Please choose a proper option.')
}